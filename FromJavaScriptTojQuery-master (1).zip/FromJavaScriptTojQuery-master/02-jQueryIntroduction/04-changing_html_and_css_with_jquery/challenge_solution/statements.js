/**
 * The set of statements that are executed in the browser console to try out
 * jQuery selectors
 */

// Modify the contents of all of the paragraph elements on the page
$("p").text("New text");