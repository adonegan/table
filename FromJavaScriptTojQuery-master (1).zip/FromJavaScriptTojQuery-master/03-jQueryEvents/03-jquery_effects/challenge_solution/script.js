$(document).ready(function() {
    $("#button_effects1").click(function(){
            $('#button_effects1').hide('slow');

        });
}); 
